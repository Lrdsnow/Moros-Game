Install mGBA (requires modding)
Open mGBA
Open game.gb