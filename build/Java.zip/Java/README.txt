If flip/java phone takes .jar:
Place Moros.jar on flip phone

if it takes .jad then 
Place Moros.jar & Moros.jad in the same place on flip phone